import Dashboard from "../components/LayoutsComponents/Dashboard";


const Dashboardmain = () => {
    return (
        <div className="  font-popins ">
           <Dashboard/>
        </div>
    );
};

export default Dashboardmain;