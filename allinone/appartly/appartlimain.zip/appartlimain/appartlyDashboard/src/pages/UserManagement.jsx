
const UserManagement = () => {
    return (
        <div>
            UserManagement
        </div>
    );
};

export default UserManagement;