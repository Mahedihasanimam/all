/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
        domains: ['localhost', '192.168.12.158','guesty-listing-images.s3.amazonaws.com','assets.guesty.com','res.cloudinary.com'],
    },
};

export default nextConfig;
